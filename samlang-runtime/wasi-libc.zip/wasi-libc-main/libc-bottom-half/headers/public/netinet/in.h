#ifndef __wasilibc_netinet_in_h
#define __wasilibc_netinet_in_h

#include <__header_netinet_in.h>

#endif
