#ifndef __wasilibc_sys_stat_h
#define __wasilibc_sys_stat_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc stat implementations.
 */
#include <__header_sys_stat.h>

#endif
