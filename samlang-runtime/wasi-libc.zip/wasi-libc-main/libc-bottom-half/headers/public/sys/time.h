#ifndef __wasilibc_sys_time_h
#define __wasilibc_sys_time_h

#include <__struct_timeval.h>

#endif
