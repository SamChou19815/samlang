#ifndef __wasilibc_errno_h
#define __wasilibc_errno_h

#include <__errno.h>
#include <__errno_values.h>

#endif
