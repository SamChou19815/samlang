#ifndef __wasilibc_wchar_h
#define __wasilibc_wchar_h

#define __need_size_t
#define __need_wchar_t
#define __need_NULL
#include <stddef.h>

#endif
