#ifndef __wasilibc_unistd_h
#define __wasilibc_unistd_h

/*
 * Include the real implementation, which is factored into a separate file so
 * that it can be reused by other libc unistd implementations.
 */
#include <__header_unistd.h>

#endif
